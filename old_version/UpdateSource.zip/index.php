<?php
	include ('includes/header.inc.php'); 
	include ('includes/top_nav.inc.php'); ?>
  
  	<div class="parent_content">
    <div id='inside_content_wrapper' style="padding-bottom:280px;">
    </div>
	<img class="announcement-dialog" id="img-accouncement" alt="announcement" src="<?php echo $lang['img-announcement']?>" style="border: 0; width: 85%; cursor: pointer;" class="bcancel"></div>
	<?php  include ('includes/footer.inc.php');  ?>